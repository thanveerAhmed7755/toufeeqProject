import React, { useEffect } from 'react'
import data from "../Json-Data/data.json"
import { useState } from 'react'
import { Link,useNavigate } from 'react-router-dom'
import "./custom.css"
const User = () => {

    const [details,setDetails] = useState('')
    const [dData,setdData] = useState([])
    const [sample,setSample] = useState([])
    const [adminName,setAdminName] = useState('')
    const [adminPassword,setAdminPassword]= useState('')
    const navigate = useNavigate()
    


    const AdminPanel = () => 
    {
        return<>
          <div className='z-3 fixed top-10'>
            <form action="#" onClick={(e) => 
            {
               e.preventDefault();
            }}>
            <div>
                <h1>Enter your credentials..</h1>
            </div>
            <div>
                <input type="text" placeholder='Admin Username or Email' name="" id="" />
            </div>
            <div>
                <input type="password" placeholder='Admin password' name="" id="" />
            </div>
            <div>
                <input type="submit" value="" />
            </div>
            </form>
          </div>
        </>
    }

    useEffect(() => 
    {

        const filteredData = data.filter((el,index) => 
            {
                return (
                    (el.username+'@gmail.com' === localStorage.getItem('email'))
                    &&
                    (el.password == localStorage.getItem('password'))
                )
            })
            setSample(filteredData)
        
            setDetails(sample.map(el => el.fullName))
    },[])

  return (
    <>
      <div className='w-[100%] h-[100vh]' >
        <div className='user-parent h-[45%] text-white'>
      <header className='flex items-center justify-between px-3 py-3'>
        <div className="logo">
            <h1 className='text-2xl' >SKAS</h1>
        </div>
        <ul className='flex gap-2 '>
            <li>
                <p className='underline cursor-pointer'
                onClick={() => 
                {
                    let update = confirm('Are you an admin?',);
                    if(update)
                    {
                      setAdminName(prompt('Enter admin username'))
                      setAdminPassword(prompt('Enter admin password'))
                      if(adminName == "" || adminPassword)
                      {
                        alert('Please fill out admin credentials..')
                      }
                      else 
                      {
                        navigate('/admin')
                      }
                    }
                }}
                >
                    Administrator
                </p>
            </li>
            <li>
               <Link className='underline' to="/" onClick={() => 
               {
                localStorage.removeItem('email')
               }}
               >Logout</Link> 
            </li>
        </ul>
      </header>
      <div className='w-[100%] h-[55%] mt-[2.8rem]'>
          <div>
          <div>
          <h1 className='text-4xl mt-2 text-center'>Hi, {sample.map(el => el.fullName)}!</h1>
          </div>
            <marquee>
                <h1 className='text-2xl mt-12'>Welcome to your Dashboard!</h1>
            </marquee>
          </div>
          </div>
         <div className='w-[90%] mx-auto py-4 text-start  text-black mt-3'>
        {sample.map((el) => 
        {
          
            return <>
            <div className='flex items-center'>  
            </div>
             <div className='flex items-center gap-2 py-1'>
             <span className="material-symbols-outlined">
school
</span><h1>{el.degree}</h1>
             </div>
             <div className='flex items-center gap-2 py-1'>
             <span className="material-symbols-outlined">
import_contacts
</span><h1>{el.department}</h1>
             </div>

             <div className='flex items-center gap-2 py-1'>
             <span className="material-symbols-outlined">
mail
</span> <h1 className=''>Address  - {el.address}</h1>
             </div>
             <div className='flex items-center gap-2 py-1'>
             <span className="material-symbols-outlined">
call
</span> <h1>{el.mobileNumber}</h1>
             </div>
             <div className='flex items-center gap-2 py-1'>
             <span className="material-symbols-outlined">
award_star
</span><h1>Your University Number : {el.universityNumber}</h1>
             </div>
             <div className='pl-6 flex items-center gap-2 py-1'>
             <h1 className='font-medium'>Total Attendace Percentage {el.attendancePercentage}%</h1>
             </div>

             <div className='mt-6'>

<div className='py-2 text-xl font-medium w-[75%] mb-4 mx-auto'>
    <h1>Sem 5 - Results</h1>
</div>

                <table className='text-center w-[75%] h-[16rem] mx-auto border-2'>
                    <thead className='border-y-2 h-[3rem] bg-gray-500 text-white'>
                      <tr>
                       <th className='border-x-2'>S. No</th>
                       <th className='border-x-2'>Subjects </th>
                       <th className='border-x-2'>Marks</th>
                      </tr>
                    </thead>
                    <tbody className='mt-2 text-center'>
                            {el.subjects.map((vl,index) => 
                            {
                                return <>
                                <tr>
                                  <td className='border-x-2'>{index+1}</td>
                                  <td className='border-x-2'>{vl}</td>
                                  <td className='border-x-2'>{sample[0].studentMarks[index]}</td>
                                </tr>
                                </>
                            })}
                    </tbody>
                </table>
             </div>
            </>
        })}
        </div>
        </div>
      </div>
    </>

  )
}

export default User
