import React from 'react'
import { Link } from 'react-router-dom'

const About = () => {
  return (
    <>
    <header className='h-[12vh] py-2 bg-teal-600 text-white flex items-center justify-between px-4'>
         <div className="logo">
            <h1 className='text-xl'>SCAC</h1>
         </div>
         <div className="link">
            <ul className='flex gap-3 text-[13px]'>
                <li>
                    <Link to='/'>Home</Link>
                </li>
                <li>
                    <Link to="/login">Login</Link>
                </li>
            </ul>
         </div>
    </header>
    <div className="about-body w-screen h-[88vh]">
      <h1>This is the About Page</h1>
    </div>
    </>
  )
}

export default About
