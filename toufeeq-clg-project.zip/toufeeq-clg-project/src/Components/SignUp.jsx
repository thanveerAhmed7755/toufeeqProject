import React from 'react'
import './custom.css'
import { Link } from 'react-router-dom'

const SignUp = () => {
  return (
    <div className="signup-parent w-[100%] h-screen ">

<header className='h-[10vh] py-2 text-white flex items-center justify-between px-4'>
         <div className="logo">
            <h1 className='text-xl'>SCAC</h1>
         </div>
         <div className="link">
            <ul className='flex gap-3 text-[13px]'>
                <li>
                    <Link to="/">Home</Link>
                </li>
                <li>
                    <Link to='/about' >About</Link>
                </li>
            </ul>
         </div>
    </header>

      <div className=' h-[90vh] flex items-center justify-center'>
    <div className='w-[55%] lg:w-[45%] md:w-[45%] sm:w-[45%] text-center'>
      <form action="#" className='rounded-md w-[100%] py-3'>
        <div className="title pb-4">
            <h1 className='text-white text-3xl'>
                Signup
            </h1>
        </div>
        <div className='m-4 w-[75%] mx-auto flex items-center'>
        
            <input type="text" placeholder='FIrst Name'  className=' w-[100%] text-sm
             border-2 px-2 py-2 rounded-sm outline-none bg-transparent text-white placeholder:text-white
            ' name="" id="" />
        </div>

        <div className='m-4 w-[75%] mx-auto flex items-center'>
        
        <input type="text" placeholder='Last Name'  className=' w-[100%] text-sm
         border-2 px-2 py-2 rounded-sm outline-none bg-transparent text-white placeholder:text-white
        ' name="" id="" />
    </div>

        <div className='m-4 w-[75%] mx-auto flex items-center'>
        
            <input type="email" placeholder='Email'  className=' w-[100%] text-sm
             border-2 px-2 py-2 rounded-sm outline-none bg-transparent text-white placeholder:text-white
            ' name="" id="" />
        </div>
        <div className='m-4 w-[75%] mx-auto flex items-center'>
       
            <input type="password" placeholder='Password' className='w-[100%] text-sm
             border-2 px-2 py-2 rounded-sm outline-none bg-transparent text-white placeholder:text-white
            ' name="" id="" />
        </div>

        <div className='m-4 w-[75%] mx-auto flex items-center'>
       
       <input type="password" placeholder='Confirm Password' className='w-[100%] text-sm
        border-2 px-2 py-2 rounded-sm outline-none bg-transparent text-white placeholder:text-white
       ' name="" id="" />
   </div>


   <div className='m-4 w-[75%] mx-auto flex items-center'>
       
       <input type="text" placeholder='Mobile Number' className='w-[100%] text-sm
        border-2 px-2 py-2 rounded-sm outline-none bg-transparent text-white placeholder:text-white
       ' name="" id="" />
   </div>

   <div className='m-4 w-[75%] mx-auto flex items-center'>
       
       <input type="text" placeholder='Address' className='w-[100%] text-sm
        border-2 px-2 py-2 rounded-sm outline-none bg-transparent text-white placeholder:text-white
       ' name="" id="" />
   </div>

        <div className='m-1 text-start w-[70%] mx-auto flex text-white gap-2 text-[12px] items-center justify-end'>
           <p>Already have an account?</p> <Link to="/login" className='hover:text-white text-white text-sm underline'>Login</Link>
        </div>
        <div className='py-2'>
            <button onClick={(e) => 
            {
                 e.preventDefault()
            }} className='text-white bg-[#001923] px-3 py-2 text-sm rounded-md'>submit</button>
        </div>
      </form>
    </div>
    </div>
    </div>
  )
}

export default SignUp
