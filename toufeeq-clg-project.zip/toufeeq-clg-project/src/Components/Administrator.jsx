import React from 'react'
import data from "../Json-Data/data.json"

const Administrator = () => {
  return (
    <>
      <div className='w-[100%] h-[100vh]'>
           <div className='text-center'>
            <h1 className='text-2xl'>Student Details</h1>
           </div>
           <div className='mt-2 w-[80%] mx-auto'
           >
            {
                data.map((el) => 
                {
                    return <>
                      {
                        <div className='w-[100%] mb-2 rounded-md text-white pl-5 bg-black px-2 py-2'>
                            <h1>{el.fullName}</h1>
                            <p>{el.department}</p>
                            <p>{el.degree}</p>
                            <p>{el.universityNumber}</p>
                        </div>
                      }
                    </>
                })
            }
           </div>
      </div>
    </>
  )
}

export default Administrator
