import React from 'react'
import { Link } from 'react-router-dom'
import "./custom.css"
const Welcome = () => {
  return (
   <>
   <div className='body'>
    <header className='h-[12vh] py-2 text-white flex items-center justify-between px-4'>
         <div className="logo">
            <h1 className='text-xl' style={{"letterSpacing":"2px"}}>MSCAS</h1>
         </div>
         <div className="link">
            <ul className='flex gap-3 text-[13px]'>
                <li>
                    <Link to='/'>Home</Link>
                </li>
                <li>
                    {/* <Link to="/about" >About</Link> */}
                </li>
                <li>
                    <Link to="/login">Login</Link>
                </li>
            </ul>
         </div>
    </header>
    <div className=" w-[100%] h-[88vh] flex items-center justify-center flex-col gap-5 px-4 text-white">
        <div className="title text-center">

      <h1 className='text-xl'>Welcome to the SATHAK COLLEGE OF ARTS OF SCIENCE</h1>
        </div>
        <div className="message text-center">
            <p>
                In our college, we provide the best and better education to the future challengers and placements.
            </p>
        </div>
        <div className="explore mt-4">
            <Link className='hover:text-black hover:bg-white  px-2 py-2 border rounded-md'>Explore</Link>
        </div>
       
    </div>
   </div>
   </>
  )
}

export default Welcome
