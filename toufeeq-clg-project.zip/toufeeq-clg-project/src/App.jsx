import { useState } from 'react'
import Login from './Components/Login'
import SignUp from './Components/SignUp'
import Welcome from './Components/Welcome'
import { BrowserRouter,Routes as Switch,Route } from 'react-router-dom'
import About from './Components/About'
import User from './Components/User'
import Administrator from './Components/Administrator'

function App() {
  return (
    <>
    <BrowserRouter>
        <Switch>
          <Route path="/" element={<Welcome />} />
         <Route path="/login" element={<Login />} />
         <Route path="/signup" element={<SignUp />} />
         <Route path="/about" element={<About />} />
         <Route path="/user" element={<User />} />
         <Route path="/admin" element={<Administrator />} />
        </Switch>
    </BrowserRouter>
    </>
  )
}

export default App
