/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./src/**/*.{js,,css,html,jsx}",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}

